const fs = require('fs');
const path = require('path');
const { generateRandomFingerprint } = require('../browser/fingerprint');

class ProfileStore {
  constructor(dbFilePath) {
    this.dbFilePath = dbFilePath || path.resolve(__dirname, '../../data/profiles.json');
    this.init();
  }

  init() {
    const dir = path.dirname(this.dbFilePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    if (!fs.existsSync(this.dbFilePath)) {
      const defaultProfiles = [
        {
          id: 'profile_' + Date.now() + '_1',
          name: 'Perfil Windows 11 - Gaming',
          tags: ['Personal', 'NVIDIA'],
          notes: 'Perfil optimizado con GPU NVIDIA RTX 4070 y Canvas Noise.',
          createdAt: new Date().toISOString(),
          proxy: { enabled: false, type: 'http', host: '', port: '', username: '', password: '' },
          fingerprint: generateRandomFingerprint('windows'),
          startUrl: 'https://browserleaks.com/canvas'
        },
        {
          id: 'profile_' + Date.now() + '_2',
          name: 'Perfil Mac M3 - E-Commerce',
          tags: ['Tienda', 'Apple'],
          notes: 'Perfil emulando macOS Sonoma con chip Apple M3.',
          createdAt: new Date().toISOString(),
          proxy: { enabled: false, type: 'http', host: '', port: '', username: '', password: '' },
          fingerprint: generateRandomFingerprint('mac'),
          startUrl: 'https://bot.sannysoft.com/'
        }
      ];
      fs.writeFileSync(this.dbFilePath, JSON.stringify(defaultProfiles, null, 2), 'utf8');
    }
  }

  getAll() {
    try {
      const data = fs.readFileSync(this.dbFilePath, 'utf8');
      return JSON.parse(data);
    } catch (e) {
      return [];
    }
  }

  getById(id) {
    const profiles = this.getAll();
    return profiles.find(p => p.id === id) || null;
  }

  save(profileData) {
    const profiles = this.getAll();
    if (!profileData.id) {
      profileData.id = 'profile_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5);
      profileData.createdAt = new Date().toISOString();
      profiles.unshift(profileData);
    } else {
      const index = profiles.findIndex(p => p.id === profileData.id);
      if (index >= 0) {
        profiles[index] = { ...profiles[index], ...profileData, updatedAt: new Date().toISOString() };
      } else {
        profiles.unshift(profileData);
      }
    }

    fs.writeFileSync(this.dbFilePath, JSON.stringify(profiles, null, 2), 'utf8');
    return profileData;
  }

  delete(id) {
    let profiles = this.getAll();
    const initialLen = profiles.length;
    profiles = profiles.filter(p => p.id !== id);
    if (profiles.length !== initialLen) {
      fs.writeFileSync(this.dbFilePath, JSON.stringify(profiles, null, 2), 'utf8');
      return true;
    }
    return false;
  }

  clone(id) {
    const original = this.getById(id);
    if (!original) return null;

    const cloned = JSON.parse(JSON.stringify(original));
    cloned.id = 'profile_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5);
    cloned.name = original.name + ' (Copia)';
    cloned.createdAt = new Date().toISOString();
    delete cloned.updatedAt;

    // Generar una nueva huella digital para que sea única
    cloned.fingerprint = generateRandomFingerprint(original.fingerprint?.os || 'windows');

    const profiles = this.getAll();
    profiles.unshift(cloned);
    fs.writeFileSync(this.dbFilePath, JSON.stringify(profiles, null, 2), 'utf8');
    return cloned;
  }
}

module.exports = { ProfileStore };
