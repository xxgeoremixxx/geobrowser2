const http = require('http');
const url = require('url');
const fs = require('fs');
const path = require('path');
const { generateRandomFingerprint } = require('../browser/fingerprint');
const { checkProxy } = require('../browser/proxyChecker');

class LocalApiServer {
  constructor(profileStore, browserLauncher, port = 36555) {
    this.profileStore = profileStore;
    this.browserLauncher = browserLauncher;
    this.port = port;
    this.server = null;
    this.uiDir = path.resolve(__dirname, '../ui');
  }

  start() {
    this.server = http.createServer(async (req, res) => {
      // Set CORS headers
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

      if (req.method === 'OPTIONS') {
        res.writeHead(204);
        return res.end();
      }

      const parsedUrl = url.parse(req.url, true);
      const pathname = parsedUrl.pathname;

      try {
        // --- SERVE STATIC UI FILES (for browser access at http://127.0.0.1:36555) ---
        if (req.method === 'GET' && (pathname === '/' || pathname === '/index.html')) {
          const content = fs.readFileSync(path.join(this.uiDir, 'index.html'), 'utf8');
          res.setHeader('Content-Type', 'text/html; charset=utf-8');
          res.writeHead(200);
          return res.end(content);
        }

        if (req.method === 'GET' && pathname === '/styles.css') {
          const content = fs.readFileSync(path.join(this.uiDir, 'styles.css'), 'utf8');
          res.setHeader('Content-Type', 'text/css; charset=utf-8');
          res.writeHead(200);
          return res.end(content);
        }

        if (req.method === 'GET' && pathname === '/renderer.js') {
          const content = fs.readFileSync(path.join(this.uiDir, 'renderer.js'), 'utf8');
          res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
          res.writeHead(200);
          return res.end(content);
        }

        // --- REST API ENDPOINTS ---
        res.setHeader('Content-Type', 'application/json');

        // GET /health
        if (req.method === 'GET' && pathname === '/health') {
          res.writeHead(200);
          return res.end(JSON.stringify({ status: 'ok', app: 'GeoBrowser', version: '1.0.0' }));
        }

        // GET /browser/profiles
        if (req.method === 'GET' && pathname === '/browser/profiles') {
          const profiles = this.profileStore.getAll();
          res.writeHead(200);
          return res.end(JSON.stringify(profiles));
        }

        // GET /browser/active
        if (req.method === 'GET' && pathname === '/browser/active') {
          const active = this.browserLauncher.getActiveProfiles();
          res.writeHead(200);
          return res.end(JSON.stringify({ activeProfiles: active }));
        }

        // POST /browser/profiles/save
        if (req.method === 'POST' && pathname === '/browser/profiles/save') {
          let body = '';
          req.on('data', chunk => { body += chunk; });
          req.on('end', () => {
            try {
              const data = JSON.parse(body);
              const saved = this.profileStore.save(data);
              res.writeHead(200);
              return res.end(JSON.stringify(saved));
            } catch (err) {
              res.writeHead(400);
              return res.end(JSON.stringify({ error: err.message }));
            }
          });
          return;
        }

        // POST /browser/profiles/delete
        if (req.method === 'POST' && pathname === '/browser/profiles/delete') {
          let body = '';
          req.on('data', chunk => { body += chunk; });
          req.on('end', async () => {
            try {
              const { id } = JSON.parse(body);
              if (this.browserLauncher.isProfileRunning(id)) {
                await this.browserLauncher.stop(id);
              }
              const success = this.profileStore.delete(id);
              res.writeHead(200);
              return res.end(JSON.stringify({ success }));
            } catch (err) {
              res.writeHead(400);
              return res.end(JSON.stringify({ error: err.message }));
            }
          });
          return;
        }

        // POST /browser/profiles/clone
        if (req.method === 'POST' && pathname === '/browser/profiles/clone') {
          let body = '';
          req.on('data', chunk => { body += chunk; });
          req.on('end', () => {
            try {
              const { id } = JSON.parse(body);
              const cloned = this.profileStore.clone(id);
              res.writeHead(200);
              return res.end(JSON.stringify(cloned));
            } catch (err) {
              res.writeHead(400);
              return res.end(JSON.stringify({ error: err.message }));
            }
          });
          return;
        }

        // POST /proxy/check
        if (req.method === 'POST' && pathname === '/proxy/check') {
          let body = '';
          req.on('data', chunk => { body += chunk; });
          req.on('end', async () => {
            try {
              const config = JSON.parse(body);
              const result = await checkProxy(config);
              res.writeHead(200);
              return res.end(JSON.stringify(result));
            } catch (err) {
              res.writeHead(400);
              return res.end(JSON.stringify({ error: err.message }));
            }
          });
          return;
        }

        // GET /fingerprint/random
        if (req.method === 'GET' && pathname === '/fingerprint/random') {
          const os = parsedUrl.query.os || 'windows';
          const fp = generateRandomFingerprint(os);
          res.writeHead(200);
          return res.end(JSON.stringify(fp));
        }

        // POST /browser/launch
        if (req.method === 'POST' && pathname === '/browser/launch') {
          let body = '';
          req.on('data', chunk => { body += chunk; });
          req.on('end', async () => {
            let profileId = parsedUrl.query.profileId;
            if (!profileId && body) {
              try {
                const parsedBody = JSON.parse(body);
                profileId = parsedBody.profileId;
              } catch (e) {}
            }

            if (!profileId) {
              res.writeHead(400);
              return res.end(JSON.stringify({ error: 'profileId is required' }));
            }

            const profile = this.profileStore.getById(profileId);
            if (!profile) {
              res.writeHead(404);
              return res.end(JSON.stringify({ error: 'Profile not found' }));
            }

            try {
              const launchResult = await this.browserLauncher.launch(profile);
              res.writeHead(200);
              return res.end(JSON.stringify({
                status: 'success',
                profileId,
                wsUrl: launchResult.wsEndpoint,
                debugPort: launchResult.debugPort
              }));
            } catch (err) {
              res.writeHead(500);
              return res.end(JSON.stringify({ error: err.message }));
            }
          });
          return;
        }

        // POST /browser/stop
        if (req.method === 'POST' && pathname === '/browser/stop') {
          let body = '';
          req.on('data', chunk => { body += chunk; });
          req.on('end', async () => {
            let profileId = parsedUrl.query.profileId;
            if (!profileId && body) {
              try {
                const parsedBody = JSON.parse(body);
                profileId = parsedBody.profileId;
              } catch (e) {}
            }
            if (!profileId) {
              res.writeHead(400);
              return res.end(JSON.stringify({ error: 'profileId is required' }));
            }
            const stopResult = await this.browserLauncher.stop(profileId);
            res.writeHead(200);
            return res.end(JSON.stringify(stopResult));
          });
          return;
        }

        // GET /browser/cookies
        if (req.method === 'GET' && pathname === '/browser/cookies') {
          const profileId = parsedUrl.query.profileId;
          try {
            const cookies = await this.browserLauncher.exportCookies(profileId);
            res.writeHead(200);
            return res.end(JSON.stringify(cookies));
          } catch (err) {
            res.writeHead(500);
            return res.end(JSON.stringify({ error: err.message }));
          }
        }

        // POST /browser/cookies
        if (req.method === 'POST' && pathname === '/browser/cookies') {
          let body = '';
          req.on('data', chunk => { body += chunk; });
          req.on('end', async () => {
            try {
              const { profileId, cookies } = JSON.parse(body);
              const success = await this.browserLauncher.importCookies(profileId, cookies);
              res.writeHead(200);
              return res.end(JSON.stringify({ success }));
            } catch (err) {
              res.writeHead(500);
              return res.end(JSON.stringify({ error: err.message }));
            }
          });
          return;
        }

        // 404
        res.writeHead(404);
        res.end(JSON.stringify({ error: 'Endpoint not found' }));
      } catch (err) {
        res.writeHead(500);
        res.end(JSON.stringify({ error: err.message }));
      }
    });

    this.server.on('error', (e) => {
      if (e.code === 'EADDRINUSE') {
        console.log(`[GeoBrowser] API Server ya está corriendo en el puerto ${this.port}. Reutilizando instancia.`);
      } else {
        console.error('[GeoBrowser] API Server error:', e);
      }
    });

    this.server.listen(this.port, '127.0.0.1', () => {
      console.log(`[GeoBrowser] Dashboard & API running at http://127.0.0.1:${this.port}`);
    });
  }

  stop() {
    if (this.server) {
      this.server.close();
    }
  }
}

module.exports = { LocalApiServer };
