const GPU_PRESETS = [
  { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 4090 Direct3D11 vs_5_0 ps_5_0)' },
  { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 4070 Direct3D11 vs_5_0 ps_5_0)' },
  { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0)' },
  { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce GTX 1660 SUPER Direct3D11 vs_5_0 ps_5_0)' },
  { vendor: 'Google Inc. (AMD)', renderer: 'ANGLE (AMD, AMD Radeon RX 7900 XTX Direct3D11 vs_5_0 ps_5_0)' },
  { vendor: 'Google Inc. (AMD)', renderer: 'ANGLE (AMD, AMD Radeon RX 6700 XT Direct3D11 vs_5_0 ps_5_0)' },
  { vendor: 'Apple Inc.', renderer: 'Apple M3 Max' },
  { vendor: 'Apple Inc.', renderer: 'Apple M2 Pro' }
];

const RESOLUTION_PRESETS = [
  { width: 1920, height: 1080, pixelRatio: 1 },
  { width: 2560, height: 1440, pixelRatio: 1.25 },
  { width: 1536, height: 864, pixelRatio: 1.25 },
  { width: 1440, height: 900, pixelRatio: 2 }
];

const TIMEZONE_PRESETS = [
  { id: 'America/New_York', name: 'New York (EST/EDT)', lat: 40.7128, lng: -74.0060 },
  { id: 'America/Chicago', name: 'Chicago (CST/CDT)', lat: 41.8781, lng: -87.6298 },
  { id: 'America/Los_Angeles', name: 'Los Angeles (PST/PDT)', lat: 34.0522, lng: -118.2437 },
  { id: 'Europe/London', name: 'London (GMT/BST)', lat: 51.5074, lng: -0.1278 },
  { id: 'Europe/Madrid', name: 'Madrid (CET/CEST)', lat: 40.4168, lng: -3.7038 },
  { id: 'Europe/Paris', name: 'Paris (CET/CEST)', lat: 48.8566, lng: 2.3522 },
  { id: 'America/Bogota', name: 'Bogota (COT)', lat: 4.7110, lng: -74.0721 },
  { id: 'America/Mexico_City', name: 'Mexico City (CST)', lat: 19.4326, lng: -99.1332 }
];

const USER_AGENT_PRESETS = {
  windows: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36',
  mac: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36',
  linux: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36'
};

function generateRandomFingerprint(os = 'windows') {
  const gpu = GPU_PRESETS[Math.floor(Math.random() * GPU_PRESETS.length)];
  const resolution = RESOLUTION_PRESETS[Math.floor(Math.random() * RESOLUTION_PRESETS.length)];
  const timezone = TIMEZONE_PRESETS[Math.floor(Math.random() * TIMEZONE_PRESETS.length)];
  const cores = [4, 6, 8, 12, 16][Math.floor(Math.random() * 5)];
  const ram = [8, 16, 32][Math.floor(Math.random() * 3)];
  const canvasNoiseShift = Math.floor(Math.random() * 4) + 1;

  let platform = 'Win32';
  let ua = USER_AGENT_PRESETS.windows;

  if (os === 'mac') {
    platform = 'MacIntel';
    ua = USER_AGENT_PRESETS.mac;
  } else if (os === 'linux') {
    platform = 'Linux x86_64';
    ua = USER_AGENT_PRESETS.linux;
  }

  return {
    os,
    platform,
    browser: 'chrome',
    userAgent: ua,
    hardwareConcurrency: cores,
    deviceMemory: ram,
    maxTouchPoints: 0,
    doNotTrack: '0',
    webglVendor: gpu.vendor,
    webglRenderer: gpu.renderer,
    webglMetadataMode: 'mask',
    webglImageMode: 'noise',
    resolution: resolution,
    canvasMode: 'noise',
    canvasNoise: canvasNoiseShift,
    audioMode: 'noise',
    audioNoise: true,
    clientRectsMode: 'noise',
    clientRectsNoise: 1,
    mediaDevices: {
      audioInputs: 1,
      videoInputs: 1,
      audioOutputs: 1
    },
    languages: ['es-ES', 'es', 'en-US', 'en'],
    timezone: timezone.id,
    autoTimezoneByProxy: true,
    geoMode: 'prompt',
    geolocation: {
      latitude: timezone.lat,
      longitude: timezone.lng,
      accuracy: 100
    },
    webrtcMode: 'disabled_non_proxied',
    localStorage: true,
    extStorage: true,
    plugins: true,
    clientHints: {
      mobile: false,
      platform: os === 'windows' ? 'Windows' : (os === 'mac' ? 'macOS' : 'Linux'),
      platformVersion: os === 'windows' ? '15.0.0' : '14.0.0',
      architecture: 'x86',
      bitness: '64',
      model: ''
    }
  };
}

function generateInjectionScript(fp) {
  const fpJson = JSON.stringify(fp);

  return `
    (function() {
      'use strict';
      const fp = ${fpJson};

      // 1. Hardware y Sistema (Cores, RAM, Platform, TouchPoints, DoNotTrack)
      try {
        if (fp.hardwareConcurrency) {
          Object.defineProperty(navigator, 'hardwareConcurrency', {
            get: () => fp.hardwareConcurrency,
            configurable: true
          });
        }
        if (fp.deviceMemory) {
          Object.defineProperty(navigator, 'deviceMemory', {
            get: () => fp.deviceMemory,
            configurable: true
          });
        }
        if (fp.platform) {
          Object.defineProperty(navigator, 'platform', {
            get: () => fp.platform,
            configurable: true
          });
        }
        if (fp.maxTouchPoints !== undefined) {
          Object.defineProperty(navigator, 'maxTouchPoints', {
            get: () => fp.maxTouchPoints,
            configurable: true
          });
        }
        if (fp.doNotTrack !== undefined) {
          Object.defineProperty(navigator, 'doNotTrack', {
            get: () => fp.doNotTrack,
            configurable: true
          });
        }
        if (fp.languages && fp.languages.length) {
          Object.defineProperty(navigator, 'languages', {
            get: () => fp.languages,
            configurable: true
          });
          Object.defineProperty(navigator, 'language', {
            get: () => fp.languages[0],
            configurable: true
          });
        }
      } catch (e) {}

      // 2. User-Agent Data / Client Hints
      try {
        if (navigator.userAgentData && fp.clientHints) {
          const highEntropyValues = {
            brands: [
              { brand: 'Chromium', version: '129' },
              { brand: 'Google Chrome', version: '129' },
              { brand: 'Not=A?Brand', version: '24' }
            ],
            mobile: fp.clientHints.mobile,
            platform: fp.clientHints.platform,
            platformVersion: fp.clientHints.platformVersion,
            architecture: fp.clientHints.architecture,
            bitness: fp.clientHints.bitness,
            model: fp.clientHints.model
          };

          const customUaData = {
            brands: highEntropyValues.brands,
            mobile: highEntropyValues.mobile,
            platform: highEntropyValues.platform,
            getHighEntropyValues: function(hints) {
              return Promise.resolve(highEntropyValues);
            },
            toJSON: function() {
              return {
                brands: highEntropyValues.brands,
                mobile: highEntropyValues.mobile,
                platform: highEntropyValues.platform
              };
            }
          };

          Object.defineProperty(navigator, 'userAgentData', {
            get: () => customUaData,
            configurable: true
          });
        }
      } catch (e) {}

      // 3. MediaDevices Enumeration Spoofing
      try {
        if (navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
          const originalEnumerateDevices = navigator.mediaDevices.enumerateDevices.bind(navigator.mediaDevices);
          const customEnumerateDevices = async function() {
            const devices = [];
            const audioIn = fp.mediaDevices?.audioInputs || 1;
            const videoIn = fp.mediaDevices?.videoInputs || 1;
            const audioOut = fp.mediaDevices?.audioOutputs || 1;

            for (let i = 0; i < audioIn; i++) {
              devices.push({
                deviceId: 'default_' + (i + 1),
                groupId: 'group_audio_in_' + (i + 1),
                kind: 'audioinput',
                label: 'Micrófono Realtek High Definition Audio'
              });
            }
            for (let i = 0; i < videoIn; i++) {
              devices.push({
                deviceId: 'cam_' + (i + 1),
                groupId: 'group_video_in_' + (i + 1),
                kind: 'videoinput',
                label: 'HD WebCam Pro 1080p'
              });
            }
            for (let i = 0; i < audioOut; i++) {
              devices.push({
                deviceId: 'speaker_' + (i + 1),
                groupId: 'group_audio_out_' + (i + 1),
                kind: 'audiooutput',
                label: 'Altavoces (Realtek Audio)'
              });
            }
            return devices;
          };
          
          Object.defineProperty(customEnumerateDevices, 'name', { value: 'enumerateDevices' });
          Object.defineProperty(customEnumerateDevices, 'toString', { 
            value: function() { return 'function enumerateDevices() { [native code] }'; }
          });
          
          navigator.mediaDevices.enumerateDevices = customEnumerateDevices;
        }
      } catch (e) {}

            imgData.data[i] = (imgData.data[i] + noise) % 255;
          }
          return imgData;
        };

        const originalToDataURL = HTMLCanvasElement.prototype.toDataURL;
        HTMLCanvasElement.prototype.toDataURL = function(type) {
          const context = this.getContext('2d');
          if (context && this.width > 0 && this.height > 0) {
            try {
              const imgData = context.getImageData(0, 0, Math.min(this.width, 16), Math.min(this.height, 16));
              imgData.data[0] = (imgData.data[0] + noise) % 255;
              context.putImageData(imgData, 0, 0);
            } catch (err) {}
          }
          return originalToDataURL.apply(this, arguments);
        };
      } catch (e) {}

      // 6. DOM Element & ClientRects Micro-Noise
      try {
        if (fp.clientRectsNoise) {
          const origGetBoundingClientRect = Element.prototype.getBoundingClientRect;
          Element.prototype.getBoundingClientRect = function() {
            const rect = origGetBoundingClientRect.apply(this, arguments);
            const offset = (Math.random() - 0.5) * 0.0001;
            return new DOMRect(rect.x, rect.y, rect.width + offset, rect.height + offset);
          };
        }
      } catch (e) {}

      // 7. WebGL & WebGL2 Spoofing
      try {
        const getParameter = WebGLRenderingContext.prototype.getParameter;
        WebGLRenderingContext.prototype.getParameter = function(parameter) {
          if (parameter === 37445) return fp.webglVendor || 'Google Inc. (NVIDIA)';
          if (parameter === 37446) return fp.webglRenderer || 'ANGLE (NVIDIA, NVIDIA GeForce RTX 4070 Direct3D11 vs_5_0 ps_5_0)';
          return getParameter.apply(this, arguments);
        };

        if (window.WebGL2RenderingContext) {
          const getParameter2 = WebGL2RenderingContext.prototype.getParameter;
          WebGL2RenderingContext.prototype.getParameter = function(parameter) {
            if (parameter === 37445) return fp.webglVendor || 'Google Inc. (NVIDIA)';
            if (parameter === 37446) return fp.webglRenderer || 'ANGLE (NVIDIA, NVIDIA GeForce RTX 4070 Direct3D11 vs_5_0 ps_5_0)';
            return getParameter2.apply(this, arguments);
          };
        }
      } catch (e) {}

      // 8. AudioContext Fingerprint Noise
      try {
        if (window.AudioBuffer && fp.audioNoise) {
          const originalCopyFromChannel = AudioBuffer.prototype.copyFromChannel;
          AudioBuffer.prototype.copyFromChannel = function(destination, channelNumber, startInChannel) {
            originalCopyFromChannel.apply(this, arguments);
            for (let i = 0; i < destination.length; i += 100) {
              destination[i] += 0.0000001 * (Math.random() - 0.5);
            }
          };
        }

        if (window.AnalyserNode && fp.audioNoise) {
          const originalGetFloatFrequencyData = AnalyserNode.prototype.getFloatFrequencyData;
          AnalyserNode.prototype.getFloatFrequencyData = function(array) {
            originalGetFloatFrequencyData.apply(this, arguments);
            for (let i = 0; i < array.length; i += 20) {
              array[i] += 0.001 * (Math.random() - 0.5);
            }
          };
        }
      } catch (e) {}

      // 9. Battery API Mocking
      try {
        if (navigator.getBattery) {
          navigator.getBattery = () => Promise.resolve({
            charging: true,
            chargingTime: 0,
            dischargingTime: Infinity,
            level: 1.0,
            addEventListener: () => {}
          });
        }
      } catch (e) {}

      // 10. Screen Geometry & DPI Override
      try {
        if (fp.resolution) {
          const width = fp.resolution.width;
          const height = fp.resolution.height;
          const ratio = fp.resolution.pixelRatio || 1;

          Object.defineProperty(window.screen, 'width', { get: () => width, configurable: true });
          Object.defineProperty(window.screen, 'height', { get: () => height, configurable: true });
          Object.defineProperty(window.screen, 'availWidth', { get: () => width, configurable: true });
          Object.defineProperty(window.screen, 'availHeight', { get: () => height - 40, configurable: true });
          Object.defineProperty(window, 'devicePixelRatio', { get: () => ratio, configurable: true });
        }
      } catch (e) {}

      console.log('[GeoBrowser Core] All Anti-Detect & Fingerprint Shields Activated.');
    })();
  `;
}

module.exports = {
  generateRandomFingerprint,
  generateInjectionScript,
  GPU_PRESETS,
  RESOLUTION_PRESETS,
  TIMEZONE_PRESETS,
  USER_AGENT_PRESETS
};
