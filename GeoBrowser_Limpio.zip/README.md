# GeoBrowser - Clon de GoLogin

Este proyecto es un navegador antidetección avanzado inspirado fuertemente en la interfaz y funcionamiento técnico de GoLogin.

## 🚀 Lo que hemos implementado hasta ahora:

1. **Interfaz de Usuario (UI) Idéntica a GoLogin:**
   - Tabla de perfiles con estados (OS, Tags, Proxy, Último Lanzamiento).
   - Menú de acciones (3 puntos) funcional.
   - Panel de resumen de perfil (Summary) estilo GoLogin y panel de carga de extensiones.
   - Sistema de notificaciones (Toasts) para feedback inmediato (Ej: Extensiones añadidas).

2. **Motor de Lanzamiento Seguro (Launcher):**
   - Ejecución nativa de Chromium/Chrome usando \`spawn\` (sin consola shell) para asegurar compatibilidad absoluta con rutas de Windows que contengan espacios o caracteres especiales.
   - Limpieza automática de la sesión (\`Default/Sessions\`) en cada inicio para evitar el infame problema de que "se abren las pestañas anteriores".

3. **Sistema de Proxy + Auth (Manifest V3):**
   - Integración nativa del proxy desde el milisegundo cero usando flags de Chrome (\`--proxy-server\`).
   - Autenticación invisible mediante una extensión dinámica generada "al vuelo" en formato **Manifest V3**. Esto intercepta de fondo las peticiones de usuario/contraseña del proxy, evitando ventanas emergentes y bloqueos.

4. **Gestión de Extensiones:**
   - Carga de extensiones de usuario personalizadas (Ej: Netflix).
   - Clonación directa y limpia de los archivos de extensión (\`fs.cpSync\`) hacia carpetas seguras del perfil para evadir las políticas estrictas anti-extensiones de Chromium (eliminando el uso de \`--disable-extensions-except\`).

5. **Evasión Anti-Detección (Cloudflare Turnstile / Stealth):**
   - Limpieza del código JS para evitar bloqueos por Cloudflare (eliminando variables sobrescritas como \`navigator.webdriver\` que dejan rastros).
   - Uso de parámetros de lanzamiento avanzados (\`--disable-blink-features=AutomationControlled\`, ofuscamiento WebGL nativo, etc).

## ⏳ Lo que falta por implementar o mejorar:

1. **Gestión Avanzada de Huellas (Fingerprints):**
   - Integrar una base de datos más amplia de User-Agents reales.
   - Implementar \`puppeteer-extra-plugin-stealth\` a un nivel profundo o compilar una versión de Chromium modificada (estilo Orbita/Stealthfox) para 100% de invisibilidad ante escáneres extremos como CreepJS.

2. **Nube y Sincronización:**
   - Actualmente todos los perfiles se almacenan localmente en \`~/.geobrowser\`. Falta conectar una base de datos en la nube (ej: Firebase, Supabase) para compartir cuentas entre equipos.

3. **Empaquetado y Distribución:**
   - Ofuscar el código fuente y crear un instalador \`.exe\` unificado (con \`electron-builder\`).
   - Descarga automática del binario de Chrome al iniciar la app si el usuario no lo tiene.

4. **Proxies Integrados:**
   - Conectar un proveedor de proxies rotativos directo a la UI.
