// GeoBrowser Full Renderer (Hybrid Desktop + Web API)
if (!window.geoApi) {
  const API_URL = 'http://127.0.0.1:36555';
  window.geoApi = {
    getProfiles: async () => (await fetch(`${API_URL}/browser/profiles`)).json(),
    getProfile: async (id) => {
      const all = await (await fetch(`${API_URL}/browser/profiles`)).json();
      return all.find(p => p.id === id) || null;
    },
    saveProfile: async (profile) => (await fetch(`${API_URL}/browser/profiles/save`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(profile)
    })).json(),
    deleteProfile: async (id) => (await fetch(`${API_URL}/browser/profiles/delete`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    })).json(),
    cloneProfile: async (id) => (await fetch(`${API_URL}/browser/profiles/clone`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    })).json(),
    launchProfile: async (id) => {
      const res = await fetch(`${API_URL}/browser/launch`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ profileId: id })
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Error al lanzar perfil');
      }
      return res.json();
    },
    stopProfile: async (id) => (await fetch(`${API_URL}/browser/stop`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ profileId: id })
    })).json(),
    getActiveProfiles: async () => {
      const data = await (await fetch(`${API_URL}/browser/active`)).json();
      return data.activeProfiles || [];
    },
    exportCookies: async (id) => (await fetch(`${API_URL}/browser/cookies?profileId=${id}`)).json(),
    importCookies: async (id, cookies) => (await fetch(`${API_URL}/browser/cookies`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ profileId: id, cookies })
    })).json(),
    checkProxy: async (proxyConfig) => (await fetch(`${API_URL}/proxy/check`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(proxyConfig)
    })).json(),
    generateRandomFingerprint: async (os) => {
      const resp = await fetch(`${API_URL}/fingerprint/random?os=${os || 'windows'}`);
      return await resp.json();
    },
    getAvailableBrowsers: async () => [],
    selectFolder: async () => {
      // Web mode fallback: prompt the user
      const folder = prompt('Pega la ruta de la carpeta de extensión:');
      return folder || null;
    },
    onProfileStatusChange: (callback) => {
      setInterval(async () => {
        try {
          const act = await window.geoApi.getActiveProfiles();
          profiles.forEach(p => {
            const isAct = act.includes(p.id);
            if (isAct && !activeProfiles.has(p.id)) callback({ profileId: p.id, status: 'running' });
            if (!isAct && activeProfiles.has(p.id)) callback({ profileId: p.id, status: 'stopped' });
          });
        } catch (e) {}
      }, 2500);
    }
  };
}

// ===== TOAST NOTIFICATION SYSTEM =====
const TOAST_ICONS = {
  success: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></svg>',
  error: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>',
  info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>',
  warning: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>'
};
function showToast(title, message, type = 'info', durationMs = 3500) {
  const container = document.getElementById('toastContainer');
  if (!container) return;
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `
    <div class="toast-icon">${TOAST_ICONS[type] || TOAST_ICONS.info}</div>
    <div class="toast-body">
      <div class="toast-title">${title}</div>
      <div class="toast-msg">${message}</div>
    </div>
    <button class="toast-close">&times;</button>
  `;
  toast.querySelector('.toast-close').addEventListener('click', () => removeToast(toast));
  container.appendChild(toast);
  setTimeout(() => removeToast(toast), durationMs);
}
function removeToast(toast) {
  if (!toast || toast.classList.contains('toast-exit')) return;
  toast.classList.add('toast-exit');
  setTimeout(() => toast.remove(), 300);
}

// ===== FOLDER PICKER FALLBACK =====
async function pickFolder() {
  // Try Electron IPC first
  if (window.geoApi && typeof window.geoApi.selectFolder === 'function') {
    try {
      const folder = await window.geoApi.selectFolder();
      if (folder) return folder;
      return null;
    } catch (e) {
      console.warn('selectFolder IPC failed:', e);
    }
  }
  // Fallback: use a hidden directory-picker input
  return new Promise(resolve => {
    const input = document.createElement('input');
    input.type = 'file';
    input.webkitdirectory = true;
    input.style.display = 'none';
    document.body.appendChild(input);
    input.addEventListener('change', () => {
      if (input.files && input.files.length > 0) {
        // Extract directory path from the first file's webkitRelativePath
        const firstFile = input.files[0];
        const fullPath = firstFile.path || firstFile.webkitRelativePath;
        if (firstFile.path) {
          // Electron gives us .path
          const dirPath = firstFile.path.substring(0, firstFile.path.lastIndexOf(require ? '\\' : '/'));
          resolve(dirPath);
        } else {
          resolve(fullPath.split('/')[0]);
        }
      } else {
        resolve(null);
      }
      input.remove();
    });
    input.addEventListener('cancel', () => { resolve(null); input.remove(); });
    input.click();
  });
}

let profiles = [];
let activeProfiles = new Set();
let savedProxies = [];
let globalExtensions = [];
let searchQuery = '';
let contextProfileId = null;
let editingProfile = null;
let editExtensions = [];

// Init
document.addEventListener('DOMContentLoaded', async () => {
  await loadProfiles();
  await updateActive();
  setupNav();
  setupSearch();
  setupContextMenu();
  setupEditPage();
  setupProxiesView();
  setupExtensionsView();
  setupCookieModal();

  document.getElementById('btnAddProfile').addEventListener('click', createNewProfile);
  document.getElementById('btnQuickCreate').addEventListener('click', createQuickProfile);

  if (window.geoApi?.onProfileStatusChange) {
    window.geoApi.onProfileStatusChange(({ profileId, status }) => {
      status === 'stopped' ? activeProfiles.delete(profileId) : activeProfiles.add(profileId);
      renderTable();
      updateStats();
    });
  }
});

// DATA
async function loadProfiles() {
  profiles = window.geoApi ? await window.geoApi.getProfiles() : [];
  renderTable();
  updateStats();
}
async function updateActive() {
  if (window.geoApi) {
    activeProfiles = new Set(await window.geoApi.getActiveProfiles());
    renderTable();
    updateStats();
  }
}
function updateStats() {
  document.getElementById('statTotal').textContent = profiles.length;
  document.getElementById('statActive').textContent = activeProfiles.size;
}

// NAV
function setupNav() {
  document.querySelectorAll('.nav-item[data-view]').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
      document.querySelectorAll('.view-panel').forEach(p => p.style.display = 'none');
      btn.classList.add('active');
      document.getElementById(btn.dataset.view).style.display = 'flex';
    });
  });
}

// SEARCH
function setupSearch() {
  document.getElementById('searchInput').addEventListener('input', e => {
    searchQuery = e.target.value.toLowerCase();
    renderTable();
  });
}

// RENDER TABLE
function getOsIcon(os) {
  return { mac: '🍎', linux: '🐧', android: '🤖' }[os] || '🪟';
}
function renderTable() {
  const tbody = document.getElementById('profileTableBody');
  const filtered = profiles.filter(p =>
    p.name.toLowerCase().includes(searchQuery) ||
    (p.tags || []).some(t => t.toLowerCase().includes(searchQuery))
  );

  if (!filtered.length) {
    tbody.innerHTML = '';
    document.getElementById('emptyState').style.display = 'flex';
    return;
  }
  document.getElementById('emptyState').style.display = 'none';

  tbody.innerHTML = filtered.map(p => {
    const running = activeProfiles.has(p.id);
    const fp = p.fingerprint || {};
    const proxyType = p.proxy?.enabled && p.proxy?.type ? `${p.proxy.type}` : 'Directo';
    const proxyLoc = p.proxy?.enabled && p.proxy?.host ? `${p.proxy.host}:${p.proxy.port}` : '—';
    return `<tr data-id="${p.id}" class="${running ? 'row-running' : ''}">
      <td><input type="checkbox" class="row-check" data-id="${p.id}"></td>
      <td><div class="profile-name-cell"><span class="os-icon">${getOsIcon(fp.os)}</span><span>${p.name}</span></div></td>
      <td><button class="btn-run ${running ? 'btn-run-stop' : 'btn-run-start'}" onclick="toggleProfile('${p.id}')">${running ? 'Stop' : 'Run'}</button></td>
      <td><span class="${running ? 'state-running' : 'state-ready'}">${running ? 'running' : 'ready'}</span></td>
      <td style="color:var(--text3);font-size:.78rem;">${p.notes || ''}</td>
      <td><span class="proxy-cell"><span class="proxy-dot"></span>${proxyType}</span></td>
      <td style="font-size:.78rem;">${proxyLoc}</td>
      <td><button class="btn-dots" onclick="showContext(event,'${p.id}')">⋯</button></td>
    </tr>`;
  }).join('');
}

// CONTEXT MENU
function setupContextMenu() {
  document.addEventListener('click', () => {
    document.getElementById('contextMenu').style.display = 'none';
  });
  document.querySelectorAll('.ctx-item').forEach(btn => {
    btn.addEventListener('click', () => handleContextAction(btn.dataset.action));
  });
}
window.showContext = (e, id) => {
    e.stopPropagation();
    contextProfileId = id;
    const menu = document.getElementById('contextMenu');
    menu.style.display = 'block';
    
    // Prevent menu from going off-screen
    const menuWidth = menu.offsetWidth;
    const menuHeight = menu.offsetHeight;
    let x = e.clientX;
    let y = e.clientY;
    
    if (x + menuWidth > window.innerWidth) {
      x = window.innerWidth - menuWidth - 10;
    }
    if (y + menuHeight > window.innerHeight) {
      y = window.innerHeight - menuHeight - 10;
    }
    
    menu.style.left = x + 'px';
    menu.style.top = y + 'px';
  };
async function handleContextAction(action) {
  const id = contextProfileId;
  if (!id) return;
  switch (action) {
    case 'settings': openEditProfile(id); break;
    case 'clone': await window.geoApi.cloneProfile(id); await loadProfiles(); break;
    case 'cookies': openCookieModal(id); break;
    case 'history': alert('El historial se almacena en la carpeta de sesión del perfil.'); break;
    case 'copyId': navigator.clipboard.writeText(id); break;
    case 'pin': break;
    case 'delete':
      if (confirm('¿Eliminar este perfil?')) { await window.geoApi.deleteProfile(id); activeProfiles.delete(id); await loadProfiles(); }
      break;
  }
}

// TOGGLE PROFILE
window.toggleProfile = async (id) => {
  const pName = profiles.find(p => p.id === id)?.name || id;
  try {
    if (activeProfiles.has(id)) {
      await window.geoApi.stopProfile(id);
      activeProfiles.delete(id);
      showToast('Perfil detenido', `"${pName}" se cerró`, 'info');
    } else {
      await window.geoApi.launchProfile(id);
      activeProfiles.add(id);
      showToast('Perfil lanzado', `"${pName}" se está ejecutando`, 'success');
    }
  } catch (err) {
    showToast('Error al lanzar', err.message || String(err), 'error', 5000);
  }
  renderTable(); updateStats();
};

// CREATE NEW PROFILE
async function createNewProfile() {
  const fp = await window.geoApi.generateRandomFingerprint('windows');
  const p = {
    name: `Perfil #${profiles.length + 1}`,
    tags: [], notes: '', startUrl: 'https://browserleaks.com/canvas',
    proxy: { enabled: false, type: 'http', host: '', port: '', username: '', password: '' },
    fingerprint: fp, extensions: []
  };
  const saved = await window.geoApi.saveProfile(p);
  await loadProfiles();
  showToast('Perfil creado', `"${p.name}" creado con fingerprint aleatorio`, 'success');
  openEditProfile(saved.id || profiles[0]?.id);
}

async function createQuickProfile() {
  const fp = await window.geoApi.generateRandomFingerprint('windows');
  await window.geoApi.saveProfile({
    name: `Express #${Math.floor(1000 + Math.random() * 9000)}`,
    tags: ['Express'], notes: '', startUrl: 'https://browserleaks.com/canvas',
    proxy: { enabled: false }, fingerprint: fp, extensions: []
  });
  await loadProfiles();
}

// === EDIT PROFILE PAGE ===
function setupEditPage() {
  document.getElementById('backToProfiles').addEventListener('click', goBackToProfiles);
  document.getElementById('btnCancelEdit').addEventListener('click', goBackToProfiles);
  document.getElementById('btnSaveEdit').addEventListener('click', saveEditProfile);
  document.getElementById('btnRandomFp').addEventListener('click', async () => {
    const os = document.getElementById('editOs').value;
    try {
      const fp = await window.geoApi.generateRandomFingerprint(os);
      if (fp && fp.userAgent) {
        populateEditFp(fp);
        updateSummary();
        showToast('Fingerprint actualizado', `Nuevo fingerprint generado para ${os.toUpperCase()} — ${fp.webglRenderer || 'GPU aleatorio'}`, 'success');
      } else {
        showToast('Error', 'La respuesta del fingerprint fue inválida', 'error');
      }
    } catch (e) {
      showToast('Error', `No se pudo generar fingerprint: ${e.message}`, 'error');
    }
  });

  // Settings tabs
  document.querySelectorAll('.stab').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.stab').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.stab-content').forEach(c => c.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(btn.dataset.stab).classList.add('active');
    });
  });

  // Proxy pills
  document.querySelectorAll('.pill[data-ptype]').forEach(pill => {
    pill.addEventListener('click', () => {
      document.querySelectorAll('.pill[data-ptype]').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      document.getElementById('proxyCustomFields').style.display = pill.dataset.ptype === 'custom' ? 'block' : 'none';
    });
  });

  // Test proxy in edit
  document.getElementById('btnTestEditProxy').addEventListener('click', async () => {
    const msg = document.getElementById('editProxyMsg');
    msg.textContent = 'Probando...'; msg.style.color = 'var(--text3)';
    const r = await window.geoApi.checkProxy({
      type: document.getElementById('editProxyType').value,
      host: document.getElementById('editProxyHost').value,
      port: document.getElementById('editProxyPort').value
    });
    if (r.success) { msg.textContent = `✅ Online (${r.latencyMs}ms)`; msg.style.color = 'var(--green)'; }
    else { msg.textContent = `❌ ${r.error}`; msg.style.color = 'var(--red)'; }
  });

  // Extension add in edit page
  document.getElementById('btnBrowseEditExt').addEventListener('click', async () => {
    const folder = await pickFolder();
    if (folder) {
      document.getElementById('editExtPath').value = folder;
      showToast('Carpeta seleccionada', folder, 'info');
    }
  });
  
  document.getElementById('btnAddExt').addEventListener('click', () => {
    const p = document.getElementById('editExtPath').value.trim();
    if (!p) { showToast('Campo vacío', 'Escribe o selecciona una ruta de extensión', 'warning'); return; }
    editExtensions.push(p);
    renderEditExtensions();
    document.getElementById('editExtPath').value = '';
    showToast('Extensión añadida', p.split('\\').pop() || p.split('/').pop(), 'success');
  });

  // Auto-update summary on change
  ['editOs','editResolution','editUserAgent','editLanguages','editPlatform','editCores','editRam','editCanvasMode','editWebglMode','editWebglVendor','editWebglRenderer','editAudioMode','editClientRects','editMediaDevices','editWebrtcMode','editLocalStorage','editExtStorage','editPlugins','editTimezone','editGeoMode'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('change', updateSummary);
    if (el) el.addEventListener('input', updateSummary);
  });
}

function goBackToProfiles() {
  document.querySelectorAll('.view-panel').forEach(p => p.style.display = 'none');
  document.getElementById('view-profiles').style.display = 'flex';
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById('navProfiles').classList.add('active');
}

function openEditProfile(id) {
  const profile = profiles.find(p => p.id === id);
  if (!profile) return;
  editingProfile = profile;
  editExtensions = [...(profile.extensions || [])];

  // Show edit view
  document.querySelectorAll('.view-panel').forEach(p => p.style.display = 'none');
  document.getElementById('view-edit-profile').style.display = 'flex';
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));

  // Reset tabs to overview
  document.querySelectorAll('.stab').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.stab-content').forEach(c => c.classList.remove('active'));
  document.querySelector('[data-stab="stab-overview"]').classList.add('active');
  document.getElementById('stab-overview').classList.add('active');

  // Fill fields
  document.getElementById('editId').value = profile.id;
  document.getElementById('editName').value = profile.name;
  document.getElementById('editNotes').value = profile.notes || '';
  document.getElementById('editStartUrl').value = profile.startUrl || '';

  const fp = profile.fingerprint || {};
  populateEditFp(fp);

  // Proxy
  const hasProxy = profile.proxy?.enabled && profile.proxy?.host;
  document.querySelectorAll('.pill[data-ptype]').forEach(p => p.classList.remove('active'));
  document.querySelector(`[data-ptype="${hasProxy ? 'custom' : 'none'}"]`).classList.add('active');
  document.getElementById('proxyCustomFields').style.display = hasProxy ? 'block' : 'none';
  document.getElementById('editProxyType').value = profile.proxy?.type || 'http';
  document.getElementById('editProxyHost').value = profile.proxy?.host || '';
  document.getElementById('editProxyPort').value = profile.proxy?.port || '';
  document.getElementById('editProxyUser').value = profile.proxy?.username || '';
  document.getElementById('editProxyPass').value = profile.proxy?.password || '';
  document.getElementById('editProxyMsg').textContent = '';

  // Timezone
  document.getElementById('editTimezone').value = fp.timezone || 'America/New_York';
  document.getElementById('editTzMode').value = fp.autoTimezoneByProxy ? 'auto' : 'manual';

  // Geolocation
  document.getElementById('editGeoMode').value = fp.geoMode || 'prompt';
  document.getElementById('editGeoLat').value = fp.geolocation?.latitude || 40.7128;
  document.getElementById('editGeoLng').value = fp.geolocation?.longitude || -74.0060;

  // Advanced
  document.getElementById('editHistory').value = profile.history !== false ? 'true' : 'false';
  document.getElementById('editPasswords').value = profile.passwords !== false ? 'true' : 'false';
  document.getElementById('editLaunchArgs').value = profile.launchArguments || '';
  document.getElementById('editDns').value = fp.dns || '';

  // Bookmarks
  document.getElementById('editBookmarks').value = profile.bookmarksEditing !== false ? 'true' : 'false';

  // Extensions
  renderEditExtensions();
  updateSummary();
}

function populateEditFp(fp) {
  document.getElementById('editOs').value = fp.os || 'windows';
  const res = fp.resolution ? `${fp.resolution.width}x${fp.resolution.height}` : '1920x1080';
  document.getElementById('editResolution').value = res;
  document.getElementById('editBrowser').value = fp.browser || 'chrome';
  document.getElementById('editUserAgent').value = fp.userAgent || '';
  document.getElementById('editLanguages').value = (fp.languages || ['en-US','en']).join(',');
  document.getElementById('editPlatform').value = fp.platform || 'Win32';
  document.getElementById('editCores').value = fp.hardwareConcurrency || 8;
  document.getElementById('editRam').value = fp.deviceMemory || 16;
  document.getElementById('editMaxTouch').value = fp.maxTouchPoints || 0;
  document.getElementById('editDnt').value = fp.doNotTrack || '0';
  document.getElementById('editCanvasMode').value = fp.canvasMode || 'noise';
  document.getElementById('editCanvasNoise').value = fp.canvasNoise || 1;
  document.getElementById('editWebglMode').value = fp.webglMetadataMode || 'mask';
  document.getElementById('editWebglImageMode').value = fp.webglImageMode || 'noise';
  document.getElementById('editWebglVendor').value = fp.webglVendor || '';
  document.getElementById('editWebglRenderer').value = fp.webglRenderer || '';
  document.getElementById('editAudioMode').value = fp.audioMode || (fp.audioNoise ? 'noise' : 'off');
  document.getElementById('editClientRects').value = fp.clientRectsMode || (fp.clientRectsNoise ? 'noise' : 'off');
  const md = fp.mediaDevices || {};
  document.getElementById('editMediaDevices').value = `${md.audioInputs||1}/${md.videoInputs||1}/${md.audioOutputs||1}`;
  // Handle webrtcMode from either fp.webrtcMode or fp.webrtc.mode
  const webrtcMode = fp.webrtcMode || (fp.webrtc && fp.webrtc.mode) || 'disabled_non_proxied';
  document.getElementById('editWebrtcMode').value = webrtcMode;
  document.getElementById('editLocalStorage').value = fp.localStorage !== false ? 'true' : 'false';
  document.getElementById('editExtStorage').value = fp.extStorage !== false ? 'true' : 'false';
  document.getElementById('editPlugins').value = fp.plugins !== false ? 'true' : 'false';
  // Timezone & Geo
  if (fp.timezone) document.getElementById('editTimezone').value = fp.timezone;
  if (fp.autoTimezoneByProxy !== undefined) document.getElementById('editTzMode').value = fp.autoTimezoneByProxy ? 'auto' : 'manual';
  if (fp.geolocation) {
    document.getElementById('editGeoLat').value = fp.geolocation.latitude || 40.7128;
    document.getElementById('editGeoLng').value = fp.geolocation.longitude || -74.0060;
  }
}

function renderEditExtensions() {
  const list = document.getElementById('extList');
  list.innerHTML = editExtensions.map((ext, i) =>
    `<li><span>${ext}</span><button onclick="removeEditExt(${i})">✕</button></li>`
  ).join('');
}
window.removeEditExt = (i) => { editExtensions.splice(i, 1); renderEditExtensions(); };

function updateSummary() {
  const s = document.getElementById('profileSummary');
  const items = [
    ['Profile Name', document.getElementById('editName').value],
    ['Proxy', document.querySelector('.pill.active[data-ptype]')?.dataset.ptype === 'custom' ? document.getElementById('editProxyType').value : 'none'],
    ['Browser', document.getElementById('editBrowser').value],
    ['OS', document.getElementById('editOs').value],
    ['User-Agent', document.getElementById('editUserAgent').value],
    ['Resolution', document.getElementById('editResolution').value],
    ['Languages', document.getElementById('editLanguages').value],
    ['Platform', document.getElementById('editPlatform').value],
    ['Timezone', document.getElementById('editTzMode').value === 'auto' ? 'based on ip' : document.getElementById('editTimezone').value],
    ['Geolocation', document.getElementById('editGeoMode').value],
    ['WebRTC', document.getElementById('editWebrtcMode').value],
    ['Canvas', document.getElementById('editCanvasMode').value],
    ['Client Rects', document.getElementById('editClientRects').value],
    ['WebGL Metadata', document.getElementById('editWebglMode').value],
    ['WebGL Image', document.getElementById('editWebglImageMode').value],
    ['Audio Context', document.getElementById('editAudioMode').value],
    ['Media devices', `(${document.getElementById('editMediaDevices').value})`],
    ['Local Storage', document.getElementById('editLocalStorage').value],
    ['Ext. Storage', document.getElementById('editExtStorage').value],
    ['Plugins', document.getElementById('editPlugins').value],
  ];
  s.innerHTML = items.map(([l, v]) => `<div class="summary-item"><span class="s-label">${l}:</span><span class="s-value">${v}</span></div>`).join('');
}

async function saveEditProfile() {
  const id = document.getElementById('editId').value;
  const resParts = document.getElementById('editResolution').value.split('x');
  const mdParts = document.getElementById('editMediaDevices').value.split('/');
  const isCustomProxy = document.querySelector('.pill.active[data-ptype]')?.dataset.ptype === 'custom';

  const data = {
    id,
    name: document.getElementById('editName').value,
    notes: document.getElementById('editNotes').value,
    startUrl: document.getElementById('editStartUrl').value,
    tags: editingProfile?.tags || [],
    extensions: editExtensions,
    history: document.getElementById('editHistory').value === 'true',
    passwords: document.getElementById('editPasswords').value === 'true',
    launchArguments: document.getElementById('editLaunchArgs').value,
    bookmarksEditing: document.getElementById('editBookmarks').value === 'true',
    proxy: {
      enabled: isCustomProxy && !!document.getElementById('editProxyHost').value,
      type: document.getElementById('editProxyType').value,
      host: document.getElementById('editProxyHost').value,
      port: document.getElementById('editProxyPort').value,
      username: document.getElementById('editProxyUser').value,
      password: document.getElementById('editProxyPass').value,
    },
    fingerprint: {
      os: document.getElementById('editOs').value,
      browser: document.getElementById('editBrowser').value,
      resolution: { width: parseInt(resParts[0]), height: parseInt(resParts[1]) },
      userAgent: document.getElementById('editUserAgent').value,
      languages: document.getElementById('editLanguages').value.split(','),
      platform: document.getElementById('editPlatform').value,
      hardwareConcurrency: parseInt(document.getElementById('editCores').value),
      deviceMemory: parseInt(document.getElementById('editRam').value),
      maxTouchPoints: parseInt(document.getElementById('editMaxTouch').value),
      doNotTrack: document.getElementById('editDnt').value,
      canvasMode: document.getElementById('editCanvasMode').value,
      canvasNoise: parseInt(document.getElementById('editCanvasNoise').value),
      webglMetadataMode: document.getElementById('editWebglMode').value,
      webglImageMode: document.getElementById('editWebglImageMode').value,
      webglVendor: document.getElementById('editWebglVendor').value,
      webglRenderer: document.getElementById('editWebglRenderer').value,
      audioMode: document.getElementById('editAudioMode').value,
      audioNoise: document.getElementById('editAudioMode').value === 'noise',
      clientRectsMode: document.getElementById('editClientRects').value,
      clientRectsNoise: document.getElementById('editClientRects').value === 'noise' ? 1 : 0,
      mediaDevices: { audioInputs: parseInt(mdParts[0])||1, videoInputs: parseInt(mdParts[1])||1, audioOutputs: parseInt(mdParts[2])||1 },
      webrtcMode: document.getElementById('editWebrtcMode').value,
      localStorage: document.getElementById('editLocalStorage').value === 'true',
      extStorage: document.getElementById('editExtStorage').value === 'true',
      plugins: document.getElementById('editPlugins').value === 'true',
      timezone: document.getElementById('editTimezone').value,
      autoTimezoneByProxy: document.getElementById('editTzMode').value === 'auto',
      geoMode: document.getElementById('editGeoMode').value,
      geolocation: { latitude: parseFloat(document.getElementById('editGeoLat').value), longitude: parseFloat(document.getElementById('editGeoLng').value), accuracy: 100 },
      dns: document.getElementById('editDns').value,
    }
  };

  await window.geoApi.saveProfile(data);
  await loadProfiles();
  showToast('Perfil guardado', `"${data.name}" se guardó correctamente`, 'success');
  goBackToProfiles();
}

// === PROXIES VIEW ===
function setupProxiesView() {
  document.getElementById('btnSaveProxy').addEventListener('click', () => {
    const proxy = {
      id: 'proxy_' + Date.now(),
      type: document.getElementById('savedProxyType').value,
      host: document.getElementById('savedProxyHost').value,
      port: document.getElementById('savedProxyPort').value,
      username: document.getElementById('savedProxyUser').value,
      password: document.getElementById('savedProxyPass').value,
      status: 'unknown'
    };
    if (!proxy.host || !proxy.port) return;
    savedProxies.push(proxy);
    renderSavedProxies();
    document.getElementById('savedProxyHost').value = '';
    document.getElementById('savedProxyPort').value = '';
    document.getElementById('savedProxyUser').value = '';
    document.getElementById('savedProxyPass').value = '';
  });

  document.getElementById('btnTestSavedProxy').addEventListener('click', async () => {
    const msg = document.getElementById('savedProxyMsg');
    msg.textContent = 'Probando...'; msg.style.color = 'var(--text3)';
    const r = await window.geoApi.checkProxy({
      type: document.getElementById('savedProxyType').value,
      host: document.getElementById('savedProxyHost').value,
      port: document.getElementById('savedProxyPort').value
    });
    msg.textContent = r.success ? `✅ Online (${r.latencyMs}ms)` : `❌ ${r.error}`;
    msg.style.color = r.success ? 'var(--green)' : 'var(--red)';
  });
}

function renderSavedProxies() {
  document.getElementById('savedProxiesBody').innerHTML = savedProxies.map((p, i) =>
    `<tr>
      <td>${p.type.toUpperCase()}</td><td>${p.host}</td><td>${p.port}</td><td>${p.username || '—'}</td>
      <td><span style="color:var(--text3)">${p.status}</span></td>
      <td><button class="btn-dots" onclick="removeSavedProxy(${i})">🗑️</button></td>
    </tr>`
  ).join('');
}
window.removeSavedProxy = (i) => { savedProxies.splice(i, 1); renderSavedProxies(); };

// === EXTENSIONS VIEW ===
function setupExtensionsView() {
  document.getElementById('btnBrowseGlobalExt').addEventListener('click', async () => {
    const folder = await pickFolder();
    if (folder) {
      document.getElementById('globalExtPath').value = folder;
      showToast('Carpeta seleccionada', folder, 'info');
    }
  });

  document.getElementById('btnAddGlobalExt').addEventListener('click', () => {
    const p = document.getElementById('globalExtPath').value.trim();
    if (!p) { showToast('Campo vacío', 'Escribe o selecciona una ruta de extensión', 'warning'); return; }
    globalExtensions.push(p);
    renderGlobalExtensions();
    document.getElementById('globalExtPath').value = '';
    showToast('Extensión global añadida', p.split('\\').pop() || p.split('/').pop(), 'success');
  });
}
function renderGlobalExtensions() {
  document.getElementById('globalExtList').innerHTML = globalExtensions.map((ext, i) =>
    `<li><span>${ext}</span><button onclick="removeGlobalExt(${i})">✕</button></li>`
  ).join('');
}
window.removeGlobalExt = (i) => { globalExtensions.splice(i, 1); renderGlobalExtensions(); };

// === COOKIE MODAL ===
let cookieTargetId = null;
function setupCookieModal() {
  document.getElementById('closeCookieModal').addEventListener('click', () => {
    document.getElementById('cookieModal').style.display = 'none';
  });
  document.getElementById('btnExportCookies').addEventListener('click', async () => {
    if (!cookieTargetId) return;
    try {
      const cookies = await window.geoApi.exportCookies(cookieTargetId);
      document.getElementById('cookieTextarea').value = JSON.stringify(cookies, null, 2);
    } catch (e) { document.getElementById('cookieTextarea').value = `Error: ${e.message}. El perfil debe estar en ejecución.`; }
  });
  document.getElementById('btnImportCookies').addEventListener('click', async () => {
    if (!cookieTargetId) return;
    try {
      const cookies = JSON.parse(document.getElementById('cookieTextarea').value);
      await window.geoApi.importCookies(cookieTargetId, cookies);
      alert('Cookies importadas correctamente.');
    } catch (e) { alert(`Error: ${e.message}`); }
  });
}
function openCookieModal(id) {
  cookieTargetId = id;
  document.getElementById('cookieTextarea').value = '';
  document.getElementById('cookieModal').style.display = 'flex';
}
