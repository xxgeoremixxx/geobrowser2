const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const { ProfileStore } = require('./src/database/store');
const { BrowserLauncher } = require('./src/browser/launcher');
const { generateRandomFingerprint } = require('./src/browser/fingerprint');
const { getAvailableBrowserPaths } = require('./src/browser/detector');
const { checkProxy } = require('./src/browser/proxyChecker');
const { LocalApiServer } = require('./src/server/api');

let mainWindow = null;
const profileStore = new ProfileStore();
const browserLauncher = new BrowserLauncher();
const apiServer = new LocalApiServer(profileStore, browserLauncher, 36555);

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1320,
    height: 880,
    minWidth: 1020,
    minHeight: 700,
    show: false,
    frame: true,
    autoHideMenuBar: true,
    backgroundColor: '#0b0f19',
    title: 'GeoBrowser',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'src/ui/index.html'));

  mainWindow.webContents.on('did-finish-load', () => {
    console.log('[GeoBrowser] Window content loaded successfully');
    mainWindow.show();
    mainWindow.focus();
    mainWindow.setAlwaysOnTop(true);
    setTimeout(() => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.setAlwaysOnTop(false);
      }
    }, 2000);
  });

  mainWindow.webContents.on('did-fail-load', (event, errorCode, errorDescription) => {
    console.error('[GeoBrowser] Failed to load:', errorCode, errorDescription);
  });

  // Abrir DevTools para depuración
  mainWindow.webContents.openDevTools({ mode: 'detach' });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}


// Escuchar eventos de cierre de navegador para notificar al Renderer
browserLauncher.setOnBrowserClose((profileId) => {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('browser:status-changed', {
      profileId,
      status: 'stopped'
    });
  }
});

// IPC Handlers
ipcMain.handle('profiles:getAll', async () => {
  return profileStore.getAll();
});

ipcMain.handle('profiles:getById', async (_event, id) => {
  return profileStore.getById(id);
});

ipcMain.handle('profiles:save', async (_event, profile) => {
  return profileStore.save(profile);
});

ipcMain.handle('profiles:delete', async (_event, id) => {
  if (browserLauncher.isProfileRunning(id)) {
    await browserLauncher.stop(id);
  }
  return profileStore.delete(id);
});

ipcMain.handle('profiles:clone', async (_event, id) => {
  return profileStore.clone(id);
});

ipcMain.handle('browser:launch', async (_event, id) => {
  const profile = profileStore.getById(id);
  if (!profile) throw new Error('Perfil no encontrado.');
  return await browserLauncher.launch(profile);
});

ipcMain.handle('browser:stop', async (_event, id) => {
  return await browserLauncher.stop(id);
});

ipcMain.handle('browser:getActive', async () => {
  return browserLauncher.getActiveProfiles();
});

ipcMain.handle('browser:exportCookies', async (_event, id) => {
  return await browserLauncher.exportCookies(id);
});

ipcMain.handle('browser:importCookies', async (_event, id, cookies) => {
  return await browserLauncher.importCookies(id, cookies);
});

ipcMain.handle('proxy:check', async (_event, proxyConfig) => {
  return await checkProxy(proxyConfig);
});

ipcMain.handle('fingerprint:random', async (_event, os) => {
  return generateRandomFingerprint(os || 'windows');
});

ipcMain.handle('system:browsers', async () => {
  return getAvailableBrowserPaths();
});

ipcMain.handle('system:selectFolder', async () => {
  const result = await dialog.showOpenDialog({
    properties: ['openDirectory']
  });
  if (!result.canceled && result.filePaths.length > 0) {
    return result.filePaths[0];
  }
  return null;
});

const gotTheLock = app.requestSingleInstanceLock();

if (!gotTheLock) {
  app.quit();
} else {
  app.on('second-instance', (event, commandLine, workingDirectory) => {
    // Si alguien intenta abrir una segunda instancia, enfocar la primera
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });

  app.whenReady().then(() => {
    try {
      apiServer.start();
    } catch (e) {
      console.log('API Server port in use or started already.');
    }
    createWindow();

    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0) createWindow();
    });
  });
}

app.on('before-quit', async () => {
  apiServer.stop();
  await browserLauncher.stopAll();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
