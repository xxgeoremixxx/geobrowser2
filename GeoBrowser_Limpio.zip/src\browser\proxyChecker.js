const http = require('http');
const https = require('https');

async function checkProxy(proxyConfig) {
  const startTime = Date.now();

  return new Promise((resolve) => {
    if (!proxyConfig || !proxyConfig.host || !proxyConfig.port) {
      return resolve({
        success: false,
        error: 'Host o puerto no especificado.'
      });
    }

    const host = proxyConfig.host;
    const port = parseInt(proxyConfig.port, 10);
    const type = (proxyConfig.type || 'http').toLowerCase();

    // Check basic TCP connectivity
    const net = require('net');
    const socket = new net.Socket();
    socket.setTimeout(6000);

    socket.on('connect', () => {
      const latency = Date.now() - startTime;
      socket.destroy();
      resolve({
        success: true,
        host,
        port,
        type,
        latencyMs: latency,
        status: 'Online'
      });
    });

    socket.on('timeout', () => {
      socket.destroy();
      resolve({
        success: false,
        host,
        port,
        error: 'Tiempo de espera agotado (Timeout > 6s)'
      });
    });

    socket.on('error', (err) => {
      socket.destroy();
      resolve({
        success: false,
        host,
        port,
        error: err.message || 'Error de conexión'
      });
    });

    socket.connect(port, host);
  });
}

module.exports = { checkProxy };
