const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('geoApi', {
  getProfiles: () => ipcRenderer.invoke('profiles:getAll'),
  getProfile: (id) => ipcRenderer.invoke('profiles:getById', id),
  saveProfile: (profile) => ipcRenderer.invoke('profiles:save', profile),
  deleteProfile: (id) => ipcRenderer.invoke('profiles:delete', id),
  cloneProfile: (id) => ipcRenderer.invoke('profiles:clone', id),

  launchProfile: (id) => ipcRenderer.invoke('browser:launch', id),
  stopProfile: (id) => ipcRenderer.invoke('browser:stop', id),
  getActiveProfiles: () => ipcRenderer.invoke('browser:getActive'),

  exportCookies: (id) => ipcRenderer.invoke('browser:exportCookies', id),
  importCookies: (id, cookies) => ipcRenderer.invoke('browser:importCookies', id, cookies),
  checkProxy: (proxyConfig) => ipcRenderer.invoke('proxy:check', proxyConfig),

  generateRandomFingerprint: (os) => ipcRenderer.invoke('fingerprint:random', os),
  getAvailableBrowsers: () => ipcRenderer.invoke('system:browsers'),
  selectFolder: () => ipcRenderer.invoke('system:selectFolder'),

  onProfileStatusChange: (callback) => {
    ipcRenderer.on('browser:status-changed', (_event, data) => callback(data));
  }
});
