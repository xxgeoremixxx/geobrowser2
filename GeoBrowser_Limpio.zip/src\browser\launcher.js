const puppeteer = require('puppeteer-core');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { spawn } = require('child_process');
const http = require('http');
const { generateInjectionScript } = require('./fingerprint');
const { getAvailableBrowserPaths } = require('./detector');

function getWebSocketDebuggerUrl(port, maxRetries = 30) {
  return new Promise((resolve, reject) => {
    let retries = 0;
    const interval = setInterval(() => {
      retries++;
      const req = http.get(`http://127.0.0.1:${port}/json/version`, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          try {
            const json = JSON.parse(data);
            if (json.webSocketDebuggerUrl) {
              clearInterval(interval);
              resolve(json.webSocketDebuggerUrl);
            }
          } catch (e) {}
        });
      });

      req.on('error', () => {});
      req.end();

      if (retries >= maxRetries) {
        clearInterval(interval);
        reject(new Error(`Timeout waiting for browser DevTools on port ${port}`));
      }
    }, 300);
  });
}

class BrowserLauncher {
  constructor(baseDataDir) {
    this.baseDataDir = baseDataDir || path.join(os.homedir(), '.geobrowser', 'sessions');
    this.activeBrowsers = new Map(); // profileId -> { browser, proc, wsEndpoint, port }
    this.onCloseCallback = null;

    if (!fs.existsSync(this.baseDataDir)) {
      fs.mkdirSync(this.baseDataDir, { recursive: true });
    }
  }

  setOnBrowserClose(callback) {
    this.onCloseCallback = callback;
  }

  isProfileRunning(profileId) {
    return this.activeBrowsers.has(profileId);
  }

  getActiveProfiles() {
    return Array.from(this.activeBrowsers.keys());
  }

  getProfileInfo(profileId) {
    return this.activeBrowsers.get(profileId) || null;
  }

  cleanLocks(sessionDir) {
    const lockFiles = [
      'SingletonLock',
      'SingletonSocket',
      'SingletonCookie',
      'RunningChromeVersion',
      'lockfile',
      'parent.lock'
    ];

    for (const file of lockFiles) {
      const p = path.join(sessionDir, file);
      try {
        if (fs.existsSync(p)) {
          fs.unlinkSync(p);
        }
      } catch (e) {}
    }
  }

  async launch(profile, customExecutablePath) {
    const profileId = profile.id;

    if (this.activeBrowsers.has(profileId)) {
      throw new Error(`El perfil "${profile.name}" ya se encuentra en ejecución.`);
    }

    const sessionDir = path.resolve(this.baseDataDir, profileId);
    if (!fs.existsSync(sessionDir)) {
      fs.mkdirSync(sessionDir, { recursive: true });
    }

    this.cleanLocks(sessionDir);

    const availablePaths = getAvailableBrowserPaths();
    let execCandidates = [];
    if (customExecutablePath) execCandidates.push(customExecutablePath);
    if (profile.customBrowserPath) execCandidates.push(profile.customBrowserPath);
    execCandidates.push(...availablePaths);

    if (execCandidates.length === 0) {
      throw new Error('No se encontró ningún navegador Chromium instalado en el sistema (Chrome, Brave, Edge).');
    }

    const width = profile.fingerprint?.resolution?.width || 1920;
    const height = profile.fingerprint?.resolution?.height || 1080;
    const debugPort = Math.floor(12000 + Math.random() * 38000);

    // Clear session restore files to prevent old tabs from reopening
    const sessionsDir = path.join(sessionDir, 'Default', 'Sessions');
    if (fs.existsSync(sessionsDir)) {
      try {
        fs.rmSync(sessionsDir, { recursive: true, force: true });
      } catch (e) {}
    }

    const args = [
      `--user-data-dir=${sessionDir}`,
      `--remote-debugging-port=${debugPort}`,
      `--window-size=${width},${height}`,
      '--no-default-browser-check',
      '--no-first-run',
      '--disable-blink-features=AutomationControlled',
      '--disable-infobars',
      '--test-type',
      '--disable-background-networking',
      '--disable-dev-shm-usage',
      '--password-store=basic',
      '--use-mock-keychain',
      '--disable-features=IsolateOrigins,site-per-process',
      '--force-webrtc-ip-handling-policy=disable_non_proxied_udp',
      '--enforce-webrtc-ip-permission-check',
      '--disable-session-crashed-bubble',
      '--hide-crash-restore-bubble',
      '--no-restore-session-state',
      '--restore-last-session=false',
      `--lang=${profile.fingerprint?.languages?.[0] || 'es-ES'}`
    ];

    if (profile.fingerprint?.userAgent) {
      args.push(`--user-agent=${profile.fingerprint.userAgent}`);
    }

    if (profile.launchArguments) {
      const extra = profile.launchArguments.split(' ').filter(a => a.trim().length > 0);
      args.push(...extra);
    }

    // Proxy & Authentication Extension
    let proxyExtensionDir = null;
    let extensionPaths = [];
    
    // Create a safe directory for extension copies to avoid any space/comma parsing issues
    const extSafeDir = path.join(sessionDir, 'extensions');
    if (fs.existsSync(extSafeDir)) {
      try { fs.rmSync(extSafeDir, { recursive: true, force: true }); } catch (e) {}
    }
    fs.mkdirSync(extSafeDir, { recursive: true });

    let extIndex = 0;
    if (profile.extensions && Array.isArray(profile.extensions)) {
      for (const extPath of profile.extensions) {
        try {
          if (fs.existsSync(extPath)) {
            const safeCopyPath = path.join(extSafeDir, `ext_${extIndex++}`);
            // Use full copy to completely eliminate symlink resolution issues in Chromium
            fs.cpSync(path.resolve(extPath), safeCopyPath, { recursive: true, force: true });
            extensionPaths.push(safeCopyPath);
          }
        } catch (e) {
          console.warn(`Failed to copy extension ${extPath}:`, e.message);
        }
      }
    }

    if (profile.proxy && profile.proxy.enabled && profile.proxy.host && profile.proxy.port) {
      const type = profile.proxy.type || 'http';
      
      // ALWAYS set the proxy server via command line flag so Chromium natively routes ALL traffic instantly.
      args.push(`--proxy-server=${type}://${profile.proxy.host}:${profile.proxy.port}`);

      // Generar extensión de proxy temporal SOLO para la autenticación
      if (profile.proxy.username && profile.proxy.password) {
        proxyExtensionDir = path.join(extSafeDir, 'proxy_auth_extension');
        if (!fs.existsSync(proxyExtensionDir)) fs.mkdirSync(proxyExtensionDir, { recursive: true });

        const manifest = {
          version: "1.0.0",
          manifest_version: 3,
          name: "GeoBrowser Proxy Auth",
          permissions: ["webRequest", "webRequestAuthProvider"],
          host_permissions: ["<all_urls>"],
          background: { service_worker: "background.js" }
        };

        const backgroundJs = `
chrome.webRequest.onAuthRequired.addListener(
  function(details, callbackFn) {
    callbackFn({
      authCredentials: {
        username: "${profile.proxy.username}",
        password: "${profile.proxy.password}"
      }
    });
  },
  { urls: ["<all_urls>"] },
  ["asyncBlocking"]
);
`;
        fs.writeFileSync(path.join(proxyExtensionDir, 'manifest.json'), JSON.stringify(manifest, null, 2));
        fs.writeFileSync(path.join(proxyExtensionDir, 'background.js'), backgroundJs);
        extensionPaths.push(proxyExtensionDir);
      }
    }

    // Load extensions using the safe copied paths (no spaces!)
    if (extensionPaths.length > 0) {
      const joinedExts = extensionPaths.join(',');
      args.push(`--load-extension=${joinedExts}`);
    }

    // URL inicial (must be clean URL, no extra quotes)
    const startUrl = profile.startUrl || 'about:blank';
    args.push(startUrl);

    let spawnedProc = null;
    let wsEndpoint = null;
    let browser = null;

    // Lanzamiento nativo mediante spawn desacoplado directo sin shell
    for (const execPath of execCandidates) {
      if (!fs.existsSync(execPath)) continue;
      try {
        console.log(`[GeoBrowser] Iniciando navegador: ${execPath}`);
        spawnedProc = spawn(execPath, args, {
          detached: true,
          stdio: 'ignore'
        });
        spawnedProc.unref();

        // Esperar conexión CDP
        wsEndpoint = await getWebSocketDebuggerUrl(debugPort, 25);
        if (wsEndpoint) break;
      } catch (err) {
        console.warn(`Intento fallido con ${execPath}:`, err.message);
      }
    }

    if (!wsEndpoint) {
      throw new Error('No se pudo conectar al proceso del navegador.');
    }

    // Conectar Puppeteer vía CDP para inyectar huella digital, proxy auth y timezone
    try {
      browser = await puppeteer.connect({
        browserWSEndpoint: wsEndpoint,
        defaultViewport: null
      });

      const pages = await browser.pages();
      const page = pages.length > 0 ? pages[0] : await browser.newPage();

      // Dual-layer Proxy Authentication via CDP
      if (profile.proxy?.enabled && profile.proxy?.username && profile.proxy?.password) {
        const authData = {
          username: profile.proxy.username,
          password: profile.proxy.password
        };
        for (const p of pages) {
          await p.authenticate(authData).catch(() => {});
        }
        browser.on('targetcreated', async (target) => {
          try {
            const p = await target.page();
            if (p) await p.authenticate(authData).catch(() => {});
          } catch (e) {}
        });
      }

      // Timezone & Geolocation
      try {
        const client = await page.target().createCDPSession();
        if (profile.fingerprint?.timezone) {
          await client.send('Emulation.setTimezoneOverride', {
            timezoneId: profile.fingerprint.timezone
          });
        }
        if (profile.fingerprint?.geolocation?.latitude !== undefined) {
          await client.send('Emulation.setGeolocationOverride', {
            latitude: profile.fingerprint.geolocation.latitude,
            longitude: profile.fingerprint.geolocation.longitude,
            accuracy: profile.fingerprint.geolocation.accuracy || 100
          });
        }
      } catch (e) {}

      // Fingerprint Shield Injection
      const fpScript = generateInjectionScript(profile.fingerprint || {});
      await page.evaluateOnNewDocument(fpScript);
      await page.evaluate(fpScript).catch(() => {});

      browser.on('disconnected', () => {
        this.activeBrowsers.delete(profileId);
        if (this.onCloseCallback) {
          this.onCloseCallback(profileId);
        }
      });

      this.activeBrowsers.set(profileId, { browser, proc: spawnedProc, wsEndpoint, debugPort });
    } catch (e) {
      console.log('[GeoBrowser] Browser running in standalone mode:', e.message);
      this.activeBrowsers.set(profileId, { proc: spawnedProc, wsEndpoint, debugPort });
    }

    return {
      success: true,
      profileId,
      wsEndpoint,
      debugPort
    };
  }

  async exportCookies(profileId) {
    const info = this.activeBrowsers.get(profileId);
    if (!info?.browser) {
      throw new Error('El perfil debe estar conectado para exportar cookies.');
    }
    const pages = await info.browser.pages();
    if (pages.length === 0) return [];
    return await pages[0].cookies();
  }

  async importCookies(profileId, cookies) {
    const info = this.activeBrowsers.get(profileId);
    if (!info?.browser) {
      throw new Error('El perfil debe estar conectado para importar cookies.');
    }
    const pages = await info.browser.pages();
    if (pages.length === 0) return false;
    await pages[0].setCookie(...cookies);
    return true;
  }

  async stop(profileId) {
    if (!this.activeBrowsers.has(profileId)) {
      return { success: false, message: 'El perfil no está activo.' };
    }

    const info = this.activeBrowsers.get(profileId);
    try {
      if (info.browser) await info.browser.close();
      if (info.proc && !info.proc.killed) info.proc.kill();
    } catch (e) {}
    this.activeBrowsers.delete(profileId);
    return { success: true };
  }

  async stopAll() {
    for (const [id] of this.activeBrowsers.entries()) {
      await this.stop(id);
    }
  }
}

module.exports = { BrowserLauncher };
