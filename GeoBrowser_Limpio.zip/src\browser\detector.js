const fs = require('fs');
const path = require('path');

function getAvailableBrowserPaths() {
  const localAppData = process.env.LOCALAPPDATA || '';
  const programFiles = process.env['ProgramFiles'] || 'C:\\Program Files';
  const programFilesX86 = process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)';

  const possiblePaths = [
    // Google Chrome
    path.join(programFiles, 'Google\\Chrome\\Application\\chrome.exe'),
    path.join(programFilesX86, 'Google\\Chrome\\Application\\chrome.exe'),
    path.join(localAppData, 'Google\\Chrome\\Application\\chrome.exe'),

    // Brave Browser
    path.join(programFiles, 'BraveSoftware\\Brave-Browser\\Application\\brave.exe'),
    path.join(programFilesX86, 'BraveSoftware\\Brave-Browser\\Application\\brave.exe'),
    path.join(localAppData, 'BraveSoftware\\Brave-Browser\\Application\\brave.exe'),

    // Microsoft Edge
    path.join(programFiles, 'Microsoft\\Edge\\Application\\msedge.exe'),
    path.join(programFilesX86, 'Microsoft\\Edge\\Application\\msedge.exe'),
    path.join(localAppData, 'Microsoft\\Edge\\Application\\msedge.exe'),

    // Orbita / Custom Chromium if present in local GoLogin install
    path.join(localAppData, 'Programs\\Gologin\\resources\\orbita\\chrome.exe')
  ];

  const found = possiblePaths.filter(p => fs.existsSync(p));
  return found;
}

function getDefaultBrowserPath() {
  const paths = getAvailableBrowserPaths();
  if (paths.length > 0) {
    return paths[0];
  }
  // Fallback default
  return 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
}

module.exports = {
  getAvailableBrowserPaths,
  getDefaultBrowserPath
};
